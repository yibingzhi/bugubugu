package com.easygpt.entity.dto;

public class ContentDto {
    private String content;

    public ContentDto(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
